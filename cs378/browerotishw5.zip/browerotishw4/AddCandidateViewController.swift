//
//  AddCandidateViewController.swift
//  browerotishw4
//
//  Created by Otis Brower on 9/30/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit

class AddCandidateViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var stateText: UITextField!
    @IBOutlet weak var lastnameText: UITextField!
    @IBOutlet weak var firstNameText: UITextField!
    @IBOutlet weak var polPartyBtn: UISegmentedControl!
    
    @IBOutlet weak var saveCandidate: UIButton!
    @IBOutlet weak var saveLabel: UILabel!
    
    var newFirstName: String = ""
    var newLastName: String = ""
    var newState: String = ""
    var newPolParty: String = "Democrat"
    var savedCandidate: Candidates!
    
    
    @IBAction func firstNameEnter(sender: AnyObject) {
        newFirstName = firstNameText.text!
    }
    
    @IBAction func lastNameEnter(sender: AnyObject) {
        newLastName = lastnameText.text!
    }
    
    @IBAction func stateEnter(sender: AnyObject) {
        newState = stateText.text!
    }
    
    @IBAction func polPartSelect(sender: UISegmentedControl) {
        switch polPartyBtn.selectedSegmentIndex{
        case 0:
            newPolParty = "Democrat"
        case 1:
            newPolParty = "Republican"
        default:
            break;
        }
    }
    
    @IBAction func createCandidate(sender: AnyObject) {
        let newCandidate = Candidates.init(firstName: newFirstName, lastName: newLastName, state: newState, politicalParty: newPolParty)
        newCandidate.printCandidate()
        saveLabel.text = "Candidate Saved!"
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.stateText.delegate = self
        self.lastnameText.delegate = self
        self.firstNameText.delegate = self
        self.saveLabel.text = ""
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        stateText.resignFirstResponder()
        firstNameText.resignFirstResponder()
        lastnameText.resignFirstResponder()
        stateText.resignFirstResponder()
        return true
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
