//
//  ViewController.swift
//  browerotishw4
//
//  Created by Otis Brower on 9/30/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var addCandidate: UIButton!
    @IBOutlet weak var showVotesBtn: UIButton!
    @IBOutlet weak var voteBtn: UIButton!
    @IBOutlet weak var showCandidate: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
//        if(segue.identifier == "Add Candidate"){
//            var nvc = segue.destinationViewController as! AddCandidateViewController
//        }else if(segue.identifier == "Show Candidates"){
//            
//        }else if(segue.identifier == "Vote"){
//            
//        }else if(segue.identifier == "Show Votes"){
//            
//        }
    }

    @IBAction func AddCandidateActn(sender: AnyObject) {
        performSegueWithIdentifier("AddCand", sender: self)
    }
    
    @IBAction func ShowCandidatesActn(sender: AnyObject) {
        performSegueWithIdentifier("ShowCandTable", sender: self)
    }
    
    @IBAction func VoteActn(sender: AnyObject) {
    }

    @IBAction func ShowVotesActn(sender: AnyObject) {
    }
    
}

