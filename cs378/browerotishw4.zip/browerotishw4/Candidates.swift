//
//  Candidates.swift
//  browerotishw4
//
//  Created by Otis Brower on 10/1/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import Foundation


class Candidates{
    var firstName:String
    var lastName:String
    var politicalParty:String
    var state:String
    var votes:Int
    
    
    init(firstName:String, lastName:String, state:String, politicalParty:String){
        self.firstName = firstName
        self.lastName = lastName
        self.state = state
        self.politicalParty = politicalParty
        self.votes = 0
        
    }
    
    
}