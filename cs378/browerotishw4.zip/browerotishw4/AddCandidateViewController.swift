//
//  AddCandidateViewController.swift
//  browerotishw4
//
//  Created by Otis Brower on 9/30/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit

class AddCandidateViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var stateText: UITextField!
    @IBOutlet weak var lastnameText: UITextField!
    @IBOutlet weak var firstNameText: UITextField!
    @IBOutlet weak var polPartyBtn: UISegmentedControl!
    
    
    
    @IBAction func firstNameEnter(sender: AnyObject) {
    }
    
    @IBAction func lastNameEnter(sender: AnyObject) {
    }
    
    @IBAction func stateEnter(sender: AnyObject) {
    }
    
    @IBAction func polPartSelect(sender: AnyObject) {
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.stateText.delegate = self
        self.lastnameText.delegate = self
        self.firstNameText.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
