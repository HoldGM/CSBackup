//
//  MyCollectionView.swift
//  browerotisbhw3
//
//  Created by Otis Brower on 9/26/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit

class MyCollectionView: UICollectionViewCell {
    
    @IBOutlet weak var imageCell: UIImageView!
    @IBOutlet weak var labelCell: UILabel!
    
}
