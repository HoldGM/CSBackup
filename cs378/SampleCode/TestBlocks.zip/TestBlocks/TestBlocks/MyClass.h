//
//  MyClass.h
//  TestBlocks
//
//  Created by Robert Seitsinger on 4/7/15.
//  Copyright (c) 2015 Infinity Software. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyClass : NSObject
+(void)testBlocks;

@end
