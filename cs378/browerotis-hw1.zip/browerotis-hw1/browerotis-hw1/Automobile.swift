//
//  Automobile.swift
//  browerotis-hw1
//
//  Created by Otis Brower on 9/6/15.
//  Copyright (c) 2015 CS109. All rights reserved.
//

import Cocoa

class Automobile: NSObject {
    private var make:String = "<Not Set>"
    private var model:String = "<Not Set>"
    private var numOfDoors:Int = 0
    private var speed: Int = 0
    
    
    init (make:String, model:String, numOfDoors:Int){
        self.make = make
        self.model = model
        self.numOfDoors = numOfDoors
    }


    class func create(make:String, model:String, numOfDoors:Int) -> Automobile{
        return Automobile(make: make, model:model, numOfDoors: numOfDoors)
    }
    
    func description(auto:Automobile) -> String{
        let description = "Make: \(auto.make), Model: \(auto.model), NumDoors: \(auto.numOfDoors), Speed: \(auto.speed)"
        
        return description
    }
    
    func getMake() -> String{
        return self.make
    }
    
    func setMake(make:String){
        self.make = make
    }
    
    func getModel() -> String{
        return self.model
    }
    
    func setModel(model:String){
        self.model = model
    }
    
    func getNumOfDoors() -> Int{
        return self.numOfDoors
    }
    
    func setNumOfDoors(num:Int){
        self.numOfDoors = num
    }
    
    func getSpeed() -> Int{
        return self.speed
    }
    
    func setSpeed(speed:Int){
        self.speed += speed
    }

}
