//
//  main.swift
//  browerotis-hw1
//
//  Created by Otis Brower on 9/6/15.
//  Copyright (c) 2015 CS109. All rights reserved.
//

import Foundation

func main()
{
    let a1:Automobile = Automobile.create("Maserati", model: "GranTurismo", numOfDoors: 2)
    let a2:Automobile = Automobile.create("Honda", model: "Accord", numOfDoors: 4)
    let a3:Automobile = Automobile.create("Tesla", model: "S 90", numOfDoors: 2)
    
    
    for index in 1...10{
        a1.setSpeed(Int(randomValueBetween(0, 16)))
        a2.setSpeed(Int(randomValueBetween(0, 16)))
        a3.setSpeed(Int(randomValueBetween(0, 16)))
    }
    
    println(a1.description(a1))
    println(a2.description(a2))
    println(a3.description(a3))
}

func randomValueBetween(min:UInt32, max:UInt32) -> UInt32{
    var randomValue:UInt32 = min + arc4random_uniform(UInt32(max - min + 1))
    return randomValue
}

main()
